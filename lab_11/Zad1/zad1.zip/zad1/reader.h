#pragma once

char readChar();
