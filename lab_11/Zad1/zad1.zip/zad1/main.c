#include "statemachine.h"
#include "reader.h"

int main() {
	exec();
	return 0;
}
